package egor.oop;

public enum WoolLength {
    NAKED, SHORTHAIRED, SEMILONGHAIRED, LONGHAIRED, CURLYHAIRED
}
