package egor.oop;

public enum Mood {
    NEUTRAL, BAD, GOOD
}
