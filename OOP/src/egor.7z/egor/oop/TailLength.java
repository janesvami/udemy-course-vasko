package egor.oop;

public enum TailLength {
    LONG, SHORT
}
