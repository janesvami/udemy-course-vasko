package egor.oop;

public enum LifeStage {
    BABY, YOUNG, ADULT, OLD
}
