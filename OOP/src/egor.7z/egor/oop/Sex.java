package egor.oop;

public enum Sex {
    MALE, FEMALE
}
