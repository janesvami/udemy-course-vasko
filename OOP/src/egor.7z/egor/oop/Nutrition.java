package egor.oop;

public enum Nutrition {
    HERBIVOROUS, CARNIVOROUS, OMNIVOROUS, PARASITES
}
