package egor.oop;

public abstract class Mammal<S extends Mammal<S>> extends Animal {
    private int numberOfThees;
    private int numberOfCubs;
    private TailLength tailLength;
    private boolean hasHorns;
    private boolean hasHooves;
    private boolean hasClaws;
    private WoolLength woolLength;
    private Sex sex;
    private Lifestyle lifestyle;

    public Mammal(String name, boolean isThereATail, Nutrition nutrition, int lifeExpectancy,
                  HumanInteraction humanInteraction, int yearOfBirth, LifeStage lifeStage,
                  int numberOfThees, int numberOfCubs, TailLength tailLength, boolean hasHorns,
                  boolean hasHooves, boolean hasClaws, WoolLength woolLength, Sex sex, Lifestyle lifestyle) {
        super(name, isThereATail, nutrition, lifeExpectancy, humanInteraction, yearOfBirth, lifeStage);
        this.numberOfThees = numberOfThees;
        this.numberOfCubs = numberOfCubs;
        this.tailLength = tailLength;
        this.hasHorns = hasHorns;
        this.hasHooves = hasHooves;
        this.hasClaws = hasClaws;
        this.woolLength = woolLength;
        this.sex = sex;
        this.lifestyle = lifestyle;
    }

    protected Sex getSex() {
        return sex;
    }

    protected TailLength getTailLength() {
        return tailLength;
    }

    protected WoolLength getWoolLength() {
        return woolLength;
    }

    public abstract S makeLoveWith(S crush);

    protected boolean flipACoin() {
        int minValue = 1;
        int maxValue = 10;
        int randomNumber = minValue + (int) (Math.random() * maxValue);
        return switch (randomNumber) {
            case 1, 2, 3, 4, 5 -> false;
            case 6, 7, 8, 9, 10 -> true;
            default -> throw new IllegalStateException("Unexpected value: " + randomNumber);
        };
    }

    public static boolean isLovePossible(Mammal papa, Mammal mama) {
        if (papa.equals(mama) || papa.getSex() == mama.getSex() || papa.getLifeStage() == LifeStage.BABY ||
                mama.getLifeStage() == LifeStage.BABY) {
            return false;
        } else {
            return true;
        }

    }

}
