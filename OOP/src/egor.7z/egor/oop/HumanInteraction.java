package egor.oop;

public enum HumanInteraction {
    ENEMY, NEUTRAL, FRIEND, FOOD
}
