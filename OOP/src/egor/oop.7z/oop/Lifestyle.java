package egor.oop;

public enum Lifestyle {
    AQUATIC, GROUND, UNDERGROUND, WOODY, FLYING, TRANSITIONAL
}
